(() => {
  const menuButton = document.querySelector('.menu-toggle');
  const navigation = document.querySelector('#primary-navigation');

  if (menuButton && navigation) {
    const closeMenu = () => {
      menuButton.setAttribute('aria-expanded', 'false');
      menuButton.setAttribute('aria-label', 'Open navigation menu');
      navigation.classList.remove('is-open');
    };
    menuButton.addEventListener('click', () => {
      const expanded = menuButton.getAttribute('aria-expanded') === 'true';
      menuButton.setAttribute('aria-expanded', String(!expanded));
      menuButton.setAttribute('aria-label', expanded ? 'Open navigation menu' : 'Close navigation menu');
      navigation.classList.toggle('is-open', !expanded);
    });
    navigation.addEventListener('click', (event) => {
      const target = event.target;
      if (target instanceof Element && target.closest('a')) closeMenu();
    });
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') closeMenu();
    });
    window.addEventListener('resize', () => {
      if (window.innerWidth > 680) closeMenu();
    });
  }

  document.querySelectorAll('[data-year]').forEach((element) => {
    element.textContent = String(new Date().getFullYear());
  });

  const filterButtons = [...document.querySelectorAll('.filter-button')];
  const workCards = [...document.querySelectorAll('.work-card')];
  if (filterButtons.length && workCards.length) {
    filterButtons.forEach((button) => {
      button.addEventListener('click', () => {
        const selected = button.dataset.filter || 'all';
        filterButtons.forEach((item) => {
          const active = item === button;
          item.classList.toggle('is-active', active);
          item.setAttribute('aria-pressed', String(active));
        });
        workCards.forEach((card) => {
          const categories = (card.dataset.category || '').split(/\s+/);
          card.hidden = selected !== 'all' && !categories.includes(selected);
        });
      });
    });
  }

  const dialog = document.querySelector('.project-dialog');
  if (dialog instanceof HTMLDialogElement) {
    const title = dialog.querySelector('#dialog-title');
    const description = dialog.querySelector('.dialog-description');
    const image = dialog.querySelector('.dialog-image');
    const closeButton = dialog.querySelector('.dialog-close');
    document.querySelectorAll('.work-open').forEach((button) => {
      button.addEventListener('click', () => {
        if (!(title instanceof HTMLElement) || !(description instanceof HTMLElement) || !(image instanceof HTMLImageElement)) return;
        title.textContent = button.dataset.title || 'Selected project';
        description.textContent = button.dataset.description || '';
        const imagePath = button.dataset.image || '';
        if (imagePath) {
          image.src = imagePath;
          image.alt = button.dataset.alt || '';
          image.parentElement?.removeAttribute('hidden');
        } else {
          image.removeAttribute('src');
          image.alt = '';
          image.parentElement?.setAttribute('hidden', '');
        }
        dialog.showModal();
        closeButton?.focus();
      });
    });
    closeButton?.addEventListener('click', () => dialog.close());
    dialog.addEventListener('click', (event) => {
      if (event.target === dialog) dialog.close();
    });
  }

  const form = document.querySelector('#contact-form');
  if (form instanceof HTMLFormElement) {
    const status = document.querySelector('#form-status');
    const fields = [
      { input: form.elements.namedItem('name'), errorId: 'name-error', message: 'Please enter your name (at least 2 characters).' },
      { input: form.elements.namedItem('email'), errorId: 'email-error', message: 'Please enter a valid email address.' },
      { input: form.elements.namedItem('message'), errorId: 'message-error', message: 'Please add a short message (at least 10 characters).' }
    ];
    const isValid = (input) => input instanceof HTMLInputElement || input instanceof HTMLTextAreaElement
      ? input.checkValidity()
      : true;
    const explain = (input, error, message) => {
      if (!(input instanceof HTMLElement)) return false;
      const valid = isValid(input);
      input.setAttribute('aria-invalid', String(!valid));
      error.textContent = valid ? '' : message;
      return valid;
    };
    fields.forEach(({ input, errorId, message }) => {
      const error = document.getElementById(errorId);
      if (!(error instanceof HTMLElement) || !(input instanceof HTMLElement)) return;
      input.addEventListener('input', () => explain(input, error, message));
      input.addEventListener('blur', () => explain(input, error, message));
    });
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      if (!(status instanceof HTMLElement)) return;
      status.textContent = '';
      let valid = true;
      fields.forEach(({ input, errorId, message }) => {
        const error = document.getElementById(errorId);
        if (!(error instanceof HTMLElement)) return;
        if (!explain(input, error, message)) valid = false;
      });
      if (!valid) {
        status.textContent = 'A couple of details need a quick check above.';
        form.querySelector('[aria-invalid="true"]')?.focus();
        return;
      }
      status.textContent = 'Thanks for the note! This demo form doesn’t send or save messages, but your details are filled in correctly.';
      form.reset();
      fields.forEach(({ input }) => input instanceof HTMLElement && input.removeAttribute('aria-invalid'));
      status.focus();
    });
  }
})();
