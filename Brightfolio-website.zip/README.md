# Brightfolio — responsive portfolio website

This is a static, four-page portfolio website for the fictional creative professional Jules Rivera. It uses semantic HTML, shared CSS, and vanilla JavaScript; no package install, server-side code, or database is required.

## Pages

- `index.html` — introduction and featured projects
- `about.html` — bio, services, and process
- `portfolio.html` — concept project gallery with category filters and a detail lightbox
- `contact.html` — validated demo form (it does not send or store messages)

## Run locally

Open this folder in a static web server. For example, from this directory run:

```bash
python3 -m http.server 8000
```

Then open <http://localhost:8000>. The site uses Google Fonts when online and includes local system-font fallbacks. Project photography is bundled under `assets/`; the favicon and hero illustration are also local.

## Other project files

- `styles.css` — shared responsive Electric Gallery design system
- `script.js` — mobile navigation, portfolio filtering/lightbox, and contact form demo behavior
- `manus-routes.json` — website route manifest
- `favicon.svg` / `brand-icon.png` — project-specific icon files
- `ideas.md` — approved visual direction and design decisions
- `app.config.ts` — Webdev project logo metadata
