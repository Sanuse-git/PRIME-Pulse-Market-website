# Brightfolio — design direction

## Chosen direction
**Electric Gallery** (confirmed in the project brief card). A near-black gallery canvas is interrupted by saturated color blocks, oversized project labels, and glowing micro-interactions. The mood is bold, contemporary, and slightly experimental while keeping navigation direct.

## Design dimensions
- **Design movement:** Digital neo-modernism with editorial gallery sensibility; intentional asymmetry, high contrast, and crisp geometric framing.
- **Core principles:** Keep pages simple to navigate; foreground the work; use large readable type; align shared components across all pages; make color purposeful rather than noisy.
- **Color philosophy:** Near-black surfaces (#0D0C12) and warm off-white text provide a calm gallery base. Electric violet (#6C4CFF) is the primary brand color; acid lime (#E8FF47) is the bright secondary accent for emphasis and calls to action. Muted lavender-gray supports quiet copy and borders. Preserve strong contrast and accessible focus outlines.
- **Layout paradigm:** Responsive editorial grid, generous margins, asymmetrical image and copy placement, stacked cards on small screens, and a consistent centered max-width container. Home introduces the person and highlights work; About tells the story; Portfolio prioritizes browsing/filtering; Contact reduces friction.
- **Signature elements:** A compact abstract spark/portal symbol, outlined pill navigation, oversized name typography, violet-to-lime project panels, dark project cards with numbered labels, and a bright lime CTA.
- **Interaction philosophy:** Direct, forgiving, keyboard-accessible interactions. Shared mobile menu, clear page-active state, portfolio category filtering, accessible lightbox, and a contact demo form with inline validation/success state. No interaction implies data is sent to a real service.
- **Animation:** Short restrained transitions on color, transforms, and opacity; respect `prefers-reduced-motion`; no motion required to understand the content.
- **Typography system:** Syne for display headings and wordmark; DM Sans for body, navigation, form labels, and interface copy. System sans-serif fallbacks remain available.
- **Brand essence:** Electric, curious, clear, and craft-led.
- **Brand voice:** Friendly, confident, concise, and plain-spoken.
- **Wordmark/logo:** “Jules Rivera” with a custom geometric spark/portal symbol. Use the same symbol for the favicon.
- **Signature brand color:** Electric violet (#6C4CFF), balanced by acid lime (#E8FF47).

## Content and technical implementation
The site presents fictional designer and creative developer Jules Rivera. It has four static pages (`/`, `/about.html`, `/portfolio.html`, `/contact.html`) with matching navigation and footer. Use semantic HTML5, shared CSS and vanilla JavaScript, local optimized imagery, responsive CSS Grid/Flexbox, accessible labels and focus states, hover/transition details, and no backend. The contact form is a clearly disclosed front-end demo only. The current source route manifest is `manus-routes.json` at the origin root.

## Serving approach
This is public, static portfolio content with no private or live data, so serve the static HTML/CSS/JavaScript and local image assets directly. No API server or database is needed. Keep page HTML updateable; size/compress local imagery for quick loads. The user requested a website/preview, not publication; no production route/cache config is added at this stage.
