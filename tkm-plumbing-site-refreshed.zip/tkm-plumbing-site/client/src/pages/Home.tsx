import { useMemo, useState } from "react";
import {
  ArrowRight,
  Check,
  ChevronDown,
  Clock3,
  Droplets,
  Instagram,
  Mail,
  Menu,
  Phone,
  ShieldCheck,
  Sparkles,
  Star,
  Music2,
  Wrench,
  X,
} from "lucide-react";
import { toast } from "sonner";

const image = {
  logo: "/images/TKM Plumbing.jpg",
  about: "/images/About Us Pic.jpg",
  drain: "/images/Drain Installation.jpg",
  geyser: "/images/Geyser Installation.jpg",
  heatPump: "/images/Heat Pump Installation.jpg",
  shower: "/images/Shower and Basin Installation.jpg",
  sink: "/images/Sink Installation.jpg",
  filter: "/images/Water filter Installation.jpg",
  waterLine: "/images/Water line Installation.jpg",
  tank: "/images/Water Tank Installation.jpg",
  manifold: "/images/Manifold installation.jpg",
};

const services = [
  { title: "Drain installation", description: "Smooth, dependable drainage designed to prevent blockages and keep water moving.", image: image.drain, tag: "Flow & drainage" },
  { title: "Geyser installation", description: "Safe, efficient hot-water systems installed with precision for everyday comfort.", image: image.geyser, tag: "Hot water" },
  { title: "Heat pump installation", description: "Energy-conscious heating solutions that help reduce bills without sacrificing comfort.", image: image.heatPump, tag: "Energy smart" },
  { title: "Shower & basin installation", description: "Clean, considered bathroom installations that look as good as they work.", image: image.shower, tag: "Bathroom" },
  { title: "Sink installation", description: "Durable, seamless sink fitting for kitchens, laundries and bathrooms.", image: image.sink, tag: "Everyday plumbing" },
  { title: "Water filter installation", description: "Better-tasting, cleaner water with a filter system fitted around your needs.", image: image.filter, tag: "Water quality" },
  { title: "Water line installation", description: "Reliable supply lines with careful planning to minimise leaks and future disruption.", image: image.waterLine, tag: "Supply lines" },
  { title: "Water tank installation", description: "Secure water storage solutions tailored to your home or business.", image: image.tank, tag: "Water storage" },
  { title: "Manifold installation", description: "Balanced water distribution across multiple outlets for better system control.", image: image.manifold, tag: "System control" },
];

const navItems = [
  ["Home", "home"],
  ["About", "about"],
  ["Services", "services"],
  ["Contact", "contact"],
];

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeFilter, setActiveFilter] = useState("All services");
  const [formSent, setFormSent] = useState(false);

  const filters = useMemo(() => ["All services", ...Array.from(new Set(services.map((service) => service.tag)))], []);
  const visibleServices = activeFilter === "All services" ? services : services.filter((service) => service.tag === activeFilter);

  const scrollTo = (id: string) => {
    setMenuOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setFormSent(true);
    toast.success("Thanks — your enquiry is ready to send.", { description: "TKM Plumbing will be in touch shortly." });
    event.currentTarget.reset();
  };

  return (
    <div className="site-shell" id="home">
      <header className="site-header">
        <div className="container header-inner">
          <button className="brand" onClick={() => scrollTo("home")} aria-label="TKM Plumbing home">
            <span className="brand-mark"><Droplets size={20} strokeWidth={2.5} /></span>
            <span><strong>TKM</strong><small>PLUMBING</small></span>
          </button>
          <nav className={menuOpen ? "main-nav is-open" : "main-nav"} aria-label="Main navigation">
            <button className="mobile-close" onClick={() => setMenuOpen(false)} aria-label="Close menu"><X size={22} /></button>
            {navItems.map(([label, id]) => <button key={id} className="nav-link" onClick={() => scrollTo(id)}>{label}</button>)}
            <button className="nav-cta" onClick={() => scrollTo("contact")}>Get a quote <ArrowRight size={16} /></button>
          </nav>
          <button className="mobile-menu" onClick={() => setMenuOpen(true)} aria-label="Open menu"><Menu size={24} /></button>
        </div>
      </header>

      <main>
        <section className="hero-section">
          <div className="hero-watermark">FLOW<br />FIRST</div>
          <div className="container hero-grid">
            <div className="hero-copy reveal">
              <div className="eyebrow"><span className="eyebrow-line" /> Professional plumbing, personal service</div>
              <h1>Good plumbing<br /><em>keeps life moving.</em></h1>
              <p className="hero-lede">From a careful repair to a complete water system, TKM Plumbing delivers dependable work with a finish you can feel confident about.</p>
              <div className="hero-actions">
                <button className="button button-primary" onClick={() => scrollTo("contact")}>Book a service <ArrowRight size={17} /></button>
                <button className="text-button" onClick={() => scrollTo("services")}>Explore services <span>↘</span></button>
              </div>
              <div className="hero-proof"><div className="avatar-stack"><span>TK</span><span>PM</span><span>+</span></div><span><strong>Friendly, detail-focused service</strong><br />for homes & businesses</span></div>
            </div>
            <div className="hero-visual reveal reveal-delay">
              <div className="hero-image-frame"><img src={image.logo} alt="TKM Plumbing team" /></div>
              <div className="hero-badge"><span className="badge-icon"><ShieldCheck size={20} /></span><span><strong>Trusted workmanship</strong><small>Built to last</small></span></div>
              <div className="hero-accent-dot" />
            </div>
          </div>
          <div className="hero-bottom container"><span>Scroll to discover</span><div className="scroll-line" /></div>
        </section>

        <section className="trust-strip"><div className="container trust-grid"><div className="trust-intro"><span className="mini-label">Why TKM</span><strong>Plumbing without<br />the guesswork.</strong></div><div className="trust-item"><span className="trust-icon"><Clock3 size={21} /></span><span><strong>24/7 support</strong><small>Here when it matters</small></span></div><div className="trust-item"><span className="trust-icon"><Wrench size={21} /></span><span><strong>Skilled specialists</strong><small>Precision on every job</small></span></div><div className="trust-item"><span className="trust-icon"><Star size={21} /></span><span><strong>Quality first</strong><small>Solutions that stay solved</small></span></div></div></section>

        <section className="about-section section-pad" id="about">
          <div className="container about-grid"><div className="about-image-wrap reveal"><img src={image.about} alt="TKM Plumbing at work" /><div className="about-image-note"><span>01</span><span>Hands-on<br />from start<br />to finish</span></div></div><div className="about-copy reveal reveal-delay"><div className="eyebrow"><span className="eyebrow-line" /> The TKM difference</div><h2>Crafted with care.<br /><em>Delivered with confidence.</em></h2><p>At TKM Plumbing, we believe the best work is the work you don't have to think about. Our experienced team combines practical know-how with a thoughtful approach to every installation, repair and upgrade.</p><p>Whether it is a leaky tap or a full water system, we take the time to understand the job, communicate clearly and leave your space better than we found it.</p><button className="text-button dark" onClick={() => scrollTo("contact")}>Talk to our team <ArrowRight size={16} /></button></div></div>
        </section>

        <section className="services-section section-pad" id="services"><div className="container"><div className="section-heading"><div><div className="eyebrow"><span className="eyebrow-line" /> What we do</div><h2>Solutions for every<br /><em>water moment.</em></h2></div><p>From essential maintenance to complete installations, our services are built around a simple idea: make your water work better.</p></div><div className="filter-row" role="tablist" aria-label="Filter services">{filters.map((filter) => <button key={filter} className={activeFilter === filter ? "filter-chip active" : "filter-chip"} onClick={() => setActiveFilter(filter)}>{filter}</button>)}</div><div className="services-grid">{visibleServices.map((service, index) => <article className="service-card" key={service.title}><div className="service-image-wrap"><img src={service.image} alt={service.title} /><span className="service-number">0{index + 1}</span></div><div className="service-card-content"><span className="service-tag">{service.tag}</span><h3>{service.title}</h3><p>{service.description}</p><button className="card-arrow" onClick={() => scrollTo("contact")} aria-label={`Ask about ${service.title}`}><ArrowRight size={17} /></button></div></article>)}</div></div></section>

        <section className="contact-section section-pad" id="contact"><div className="container contact-grid"><div className="contact-copy"><div className="eyebrow"><span className="eyebrow-line" /> Let's get started</div><h2>Let's make your<br /><em>water work.</em></h2><p>Tell us what you need and we'll help you find the right next step. No pressure, just clear advice from people who know plumbing.</p><div className="contact-details"><a href="tel:+27694886605"><span className="detail-icon"><Phone size={18} /></span><span><small>Call us</small><strong>+27 69 488 6605</strong></span></a><a href="mailto:tkmplumbing47@gmail.com"><span className="detail-icon"><Mail size={18} /></span><span><small>Email us</small><strong>tkmplumbing47@gmail.com</strong></span></a></div></div><form className="contact-form" onSubmit={handleSubmit}><div className="form-topline"><span>Request a callback</span><Sparkles size={16} /></div><label><span>Your name</span><input name="name" placeholder="e.g. Tshaimo Mokoena" required /></label><label><span>Email address</span><input name="email" type="email" placeholder="you@example.com" required /></label><label><span>How can we help?</span><textarea name="message" placeholder="Tell us a little about the job..." rows={4} required /></label><button className="button button-dark" type="submit">{formSent ? <><Check size={17} /> Enquiry ready</> : <>Send enquiry <ArrowRight size={17} /></>}</button><small className="form-note">We'll only use your details to respond to your enquiry.</small></form></div></section>
      </main>

      <footer className="site-footer"><div className="container footer-inner"><button className="brand footer-brand" onClick={() => scrollTo("home")}><span className="brand-mark"><Droplets size={20} /></span><span><strong>TKM</strong><small>PLUMBING</small></span></button><p>Reliable plumbing. Thoughtful service.</p><div className="footer-socials"><a href="https://www.instagram.com/" target="_blank" rel="noreferrer" aria-label="Instagram"><Instagram size={17} /></a><a href="https://wa.me/27694886605" target="_blank" rel="noreferrer" aria-label="WhatsApp"><Phone size={17} /></a><a href="https://www.tiktok.com/" target="_blank" rel="noreferrer" aria-label="TikTok"><Music2 size={17} /></a></div><span className="copyright">© {new Date().getFullYear()} TKM Plumbing</span></div></footer>
    </div>
  );
}
