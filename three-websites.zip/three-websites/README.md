# Three little websites

A compact collection of three independent, responsive websites built with plain HTML, CSS, and JavaScript.

## Open the collection

Open `index.html` in a browser. Choose a card to open a website. No install, framework, build step, or internet connection is required after downloading this folder.

## Included sites

- `cafe.html` — Little Fern Café: a café landing page with menu-category filters and button feedback.
- `travel.html` — Elsewhere: a travel discovery page with region filters and saved destinations.
- `focus.html` — Daylight: a productivity page with an interactive task list, local browser storage, progress, and a 25-minute focus timer.
- `index.html` — collection home page linking to all three.
- `assets/` — local image files used by the sites.

Each site includes its own HTML, CSS, and JavaScript in a single HTML file. User-created tasks and saved destinations are stored in the browser's local storage on that device.

## Optional local server

For consistent browser behavior, serve this folder locally:

```sh
python3 -m http.server 8000
```

Then visit `http://localhost:8000`.

## Image note

The included café, alpine-lake, and workspace photographs were selected from Unsplash image search and are bundled locally so the pages do not depend on remote image hosting.
