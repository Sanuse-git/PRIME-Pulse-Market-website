// File: product.js
// Gadget List and Comparison Script        
       
let bookmarks=[];
let comparisonList=[];

const gadgetList=document.getElementById("gadgetlist");
const  gadgetDetails=document.getElementById("gadgetDetails");
const favouriteList=document.getElementById("ProductList");
const comparisonTable=document.getElementById("comparisonTable");
const searchInput=document.getElementById("searchInput");

//== Render gadgetList==
function renderGadgetList(gadgetList){
    gadgetList.innerHtml="";
    list.forEach((gadget) => {
        const li=document.createElement("li");
        li.textContent=gadget.name;
        li.style.cursor="pointer";
        li.onclick=() => showDetails(gadget.id);
        gadgetList.appendChild(li);
    });
}
//==Show Gadget Details===
function showDetails(id){
    const gadget=gadget.find((g) => g.id==id);
    if(!gadget) return;
    

    FeaturedGadget.innerHTML=
    <h2>${gadget.name}</h2>
     
}
//== Bookmark a gadget===
function bookmarkGadget(id){
    const gadget=gadget.find((g) => g.id===id);
    if(!bookmarks.includes(gadget)){
        bookmarks.push(gadget);
        updateBookmarks();
    }
}
function updateBookmarks(){
    favouriteList.innerHTML="";
    bookmarks.forEach((gadget)=>{
        const li=document.createElement("li");
        li.textContent=gadget.name;
        favouriteList.appendChild(li);
    });
}
//=== Select for Comparison===
function selectForComparison(id){
    const gadget=gadget.find((g) => g.id=== id);
    if(!comparisonList.includes(gadget)){
        comparisonList.push(gadget);
    }
    if(comparisonList.length===2){
        renderComparison();
        comparisonList=[]// reset for compare
    }
}
function renderComparison(){
    const[gadget1,gadget2]=comparisonList;
    comparisonTable.innerHtml=
    <tr>
        <th>Feature</th>
        <th>${gadget1.name}</th>
        <th>${gadget2.name}</th>
        <tr><td>Ram</td>${gadget1.ram}
        <td>Battery</td>${gadget1.battery}<td>${gadget2.battery}</td><td>Price</td><td>${gadget1.price}</td><td>${gadget2.price}</td></tr>;
        
    </tr>

}
//==Print Spec Section only===
function PrintSpec(){
    const printConent=gadgetDetails.innerHTML;
    const originalContent=document.body.innerHTML;
    document.body.innerHTML=printConent;
    window.print();
    document.body.innerHTML=originalContent;
    //re-bind script after print
    window.location.reload();
}
//===live Search===
searchInput.addEventListener("keyup",function(){
    const query=this.ariaValueMax.toLowerCase();
    const filtered= gadgetList.filter(g =>
        g.name.toLowerCase().includes(query)
    );

    renderGadgetList(filtered)
});
//=== Initial Render
renderGadgetList(gadgets);