import { FormEvent, useMemo, useState } from "react";
import {
  ArrowUpRight,
  Bookmark,
  Check,
  ChevronDown,
  CircleHelp,
  GitCompare,
  Heart,
  Laptop,
  Menu,
  Printer,
  Search,
  Sparkles,
  Smartphone,
  SlidersHorizontal,
  Star,
  Tablet,
  Watch,
  X,
  Zap,
} from "lucide-react";

type Gadget = {
  id: string;
  name: string;
  category: string;
  tagline: string;
  description: string;
  price: number;
  rating: number;
  reviews: number;
  year: number;
  image: string;
  accent: string;
  badge?: string;
  specs: { label: string; value: string }[];
};

type CurrencyCode = "USD" | "ZAR" | "GBP";

const currencyRates: Record<CurrencyCode, number> = {
  USD: 1,
  ZAR: 18.2,
  GBP: 0.79,
};

const gadgets: Gadget[] = [
  {
    id: "pixel-9-pro",
    name: "Pixel 9 Pro",
    category: "Smartphones",
    tagline: "Pocket-sized intelligence.",
    description:
      "A beautifully balanced flagship with a pro-level camera system, all-day battery and the kind of helpful AI that stays out of your way.",
    price: 999,
    rating: 4.8,
    reviews: 284,
    year: 2024,
    image:
      "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=1200&q=85",
    accent: "violet",
    badge: "Top pick",
    specs: [
      { label: "Display", value: "6.3\" LTPO OLED · 120Hz" },
      { label: "Processor", value: "Google Tensor G4" },
      { label: "Memory", value: "16 GB RAM" },
      { label: "Storage", value: "256 GB" },
      { label: "Battery", value: "4,700 mAh · 27W charging" },
      { label: "Camera", value: "50MP triple camera" },
    ],
  },
  {
    id: "macbook-air-m3",
    name: "MacBook Air M3",
    category: "Laptops",
    tagline: "Quiet power, wherever you work.",
    description:
      "A thin, silent everyday laptop with serious creative headroom, a color-rich display and enough battery to make your charger jealous.",
    price: 1099,
    rating: 4.9,
    reviews: 461,
    year: 2024,
    image:
      "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=1200&q=85",
    accent: "coral",
    badge: "Editor’s choice",
    specs: [
      { label: "Display", value: "13.6\" Liquid Retina" },
      { label: "Processor", value: "Apple M3 · 8-core CPU" },
      { label: "Memory", value: "8 GB unified memory" },
      { label: "Storage", value: "256 GB SSD" },
      { label: "Battery", value: "Up to 18 hours" },
      { label: "Weight", value: "1.24 kg" },
    ],
  },
  {
    id: "quietcomfort-ultra",
    name: "QuietComfort Ultra",
    category: "Audio",
    tagline: "Make room for your music.",
    description:
      "Immersive spatial audio meets legendary noise cancelling in a comfortable over-ear design made for long flights and longer playlists.",
    price: 429,
    rating: 4.7,
    reviews: 198,
    year: 2024,
    image:
      "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=1200&q=85",
    accent: "lime",
    badge: "Travel hero",
    specs: [
      { label: "Audio", value: "Immersive spatial sound" },
      { label: "Noise control", value: "Adaptive ANC + aware mode" },
      { label: "Battery", value: "24 hours with ANC" },
      { label: "Connectivity", value: "Bluetooth 5.1 · multipoint" },
      { label: "Charging", value: "USB-C · 15 min = 2.5 hours" },
      { label: "Weight", value: "253 g" },
    ],
  },
  {
    id: "x100vi",
    name: "Fujifilm X100VI",
    category: "Cameras",
    tagline: "Everyday moments, elevated.",
    description:
      "A compact street-shooter with a characterful fixed lens, tactile controls and enough resolution to crop without losing the story.",
    price: 1599,
    rating: 4.9,
    reviews: 126,
    year: 2024,
    image:
      "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=1200&q=85",
    accent: "amber",
    specs: [
      { label: "Sensor", value: "40.2MP APS-C X-Trans CMOS 5 HR" },
      { label: "Lens", value: "23mm F2 fixed lens" },
      { label: "Video", value: "6.2K / 30p" },
      { label: "Viewfinder", value: "Hybrid EVF / OVF" },
      { label: "Stabilisation", value: "5-axis IBIS · 6 stops" },
      { label: "Weight", value: "521 g" },
    ],
  },
  {
    id: "galaxy-watch-7",
    name: "Galaxy Watch 7",
    category: "Wearables",
    tagline: "A smarter rhythm for your day.",
    description:
      "Health insights, quick replies and a bright circular display in a watch that looks ready for a morning run or a late-night dinner.",
    price: 299,
    rating: 4.6,
    reviews: 173,
    year: 2024,
    image:
      "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=1200&q=85",
    accent: "blue",
    specs: [
      { label: "Display", value: "1.5\" Super AMOLED" },
      { label: "Processor", value: "Exynos W1000 · 5-core" },
      { label: "Health", value: "Sleep, heart & fitness tracking" },
      { label: "Battery", value: "Up to 40 hours" },
      { label: "Durability", value: "5ATM · IP68 · MIL-STD-810H" },
      { label: "Compatibility", value: "Android 11 or later" },
    ],
  },
  {
    id: "ipad-air-m2",
    name: "iPad Air M2",
    category: "Tablets",
    tagline: "Big ideas, beautifully portable.",
    description:
      "A flexible canvas for notes, sketches, films and focused work, powered by a desktop-class chip in an easy-to-carry body.",
    price: 599,
    rating: 4.8,
    reviews: 212,
    year: 2024,
    image:
      "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?auto=format&fit=crop&w=1200&q=85",
    accent: "pink",
    specs: [
      { label: "Display", value: "11\" Liquid Retina" },
      { label: "Processor", value: "Apple M2 · 8-core CPU" },
      { label: "Memory", value: "8 GB" },
      { label: "Storage", value: "128 GB" },
      { label: "Battery", value: "Up to 10 hours" },
      { label: "Accessories", value: "Apple Pencil Pro ready" },
    ],
  },
];

const categoryIcons = {
  All: Sparkles,
  Smartphones: Smartphone,
  Laptops: Laptop,
  Audio: CircleHelp,
  Cameras: SlidersHorizontal,
  Wearables: Watch,
  Tablets: Tablet,
};

const currency = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  maximumFractionDigits: 0,
});

export default function Home() {
  const [query, setQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");
  const [selectedId, setSelectedId] = useState(gadgets[0].id);
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem("gadget-favorites") || "[]");
    } catch {
      return [];
    }
  });
  const [compareIds, setCompareIds] = useState<string[]>([]);
  const [isCompareOpen, setIsCompareOpen] = useState(false);
  const [notice, setNotice] = useState("");
  const [currencyCode, setCurrencyCode] = useState<CurrencyCode>("USD");

  function formatPrice(usdPrice: number) {
    return new Intl.NumberFormat(currencyCode === "ZAR" ? "en-ZA" : currencyCode === "GBP" ? "en-GB" : "en-US", {
      style: "currency",
      currency: currencyCode,
      maximumFractionDigits: 0,
    }).format(usdPrice * currencyRates[currencyCode]);
  }

  const categories = ["All", ...Array.from(new Set(gadgets.map((gadget) => gadget.category)))];
  const selectedGadget = gadgets.find((gadget) => gadget.id === selectedId) ?? gadgets[0];

  const filteredGadgets = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase();
    return gadgets.filter((gadget) => {
      const matchesCategory = activeCategory === "All" || gadget.category === activeCategory;
      const searchable = `${gadget.name} ${gadget.category} ${gadget.tagline}`.toLowerCase();
      return matchesCategory && (!normalizedQuery || searchable.includes(normalizedQuery));
    });
  }, [activeCategory, query]);

  const comparedGadgets = gadgets.filter((gadget) => compareIds.includes(gadget.id));
  const favoriteGadgets = gadgets.filter((gadget) => favorites.includes(gadget.id));

  function showNotice(message: string) {
    setNotice(message);
    window.setTimeout(() => setNotice(""), 2400);
  }

  function toggleFavorite(id: string) {
    const nextFavorites = favorites.includes(id)
      ? favorites.filter((favoriteId) => favoriteId !== id)
      : [...favorites, id];
    setFavorites(nextFavorites);
    localStorage.setItem("gadget-favorites", JSON.stringify(nextFavorites));
    showNotice(favorites.includes(id) ? "Removed from your favorites" : "Saved to your favorites");
  }

  function toggleCompare(id: string) {
    if (compareIds.includes(id)) {
      setCompareIds(compareIds.filter((compareId) => compareId !== id));
      return;
    }
    if (compareIds.length >= 2) {
      showNotice("Comparison is full — remove one gadget first");
      return;
    }
    setCompareIds([...compareIds, id]);
    showNotice("Added to your comparison tray");
  }

  function handleSearch(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const firstMatch = filteredGadgets[0];
    if (firstMatch) {
      setSelectedId(firstMatch.id);
      document.getElementById("detail-panel")?.scrollIntoView({ behavior: "smooth", block: "start" });
      showNotice(`${filteredGadgets.length} match${filteredGadgets.length === 1 ? "" : "es"} found`);
    } else {
      showNotice("No gadgets found — try another search");
    }
  }

  function printSpecs() {
    window.print();
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="#top" aria-label="Gadget Catalog Studio home">
          <span className="brand-mark"><Zap size={18} fill="currentColor" /></span>
          <span>gadget<span className="brand-dot">.</span>catalog</span>
        </a>
        <nav className="topnav" aria-label="Primary navigation">
          <a className="active" href="#catalog">Discover</a>
          <a href="#favorites">My favorites <span className="nav-count">{favoriteGadgets.length}</span></a>
          <a href="#how-it-works">How it works</a>
        </nav>
        <div className="topbar-meta"><span className="status-dot" /> Curated weekly <span className="meta-divider" /> <label className="currency-control"><span>Currency</span><select aria-label="Choose currency" value={currencyCode} onChange={(event) => setCurrencyCode(event.target.value as CurrencyCode)}><option value="USD">USD</option><option value="ZAR">ZAR</option><option value="GBP">GBP</option></select></label><span className="meta-divider" /> <span>v1.0</span></div>
        <button className="menu-button" type="button" aria-label="Open menu"><Menu size={20} /></button>
      </header>

      <main id="top">
        <section className="hero" aria-labelledby="hero-title">
          <div className="hero-art" aria-hidden="true"><div className="orbit orbit-one" /><div className="orbit orbit-two" /><div className="signal signal-one" /><div className="signal signal-two" /><div className="signal signal-three" /></div>
          <div className="hero-content">
            <p className="eyebrow"><span className="eyebrow-line" /> The thoughtful tech shortlist</p>
            <h1 id="hero-title">Find your next<br /><em>favorite</em> gadget.</h1>
            <p className="hero-copy">A colorful, human-first catalog for comparing the tech that makes everyday life a little more capable.</p>
            <form className="search-box" onSubmit={handleSearch}>
              <Search size={20} aria-hidden="true" />
              <input aria-label="Search gadgets" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Try “smartphone”, “camera” or “audio”" />
              <button type="submit">Search <ArrowUpRight size={17} /></button>
            </form>
            <div className="hero-chips" aria-label="Popular searches">
              <span>Popular:</span>
              {['Smartphones', 'Laptops', 'Audio'].map((item) => <button type="button" key={item} onClick={() => { setActiveCategory(item); setQuery(""); }}>{item}</button>)}
            </div>
          </div>
          <div className="hero-side-note"><span>Scroll to explore</span><span className="scroll-line" /></div>
        </section>

        <section className="catalog-layout container" id="catalog">
          <aside className="sidebar">
            <div className="section-kicker">01 / Browse</div>
            <div className="sidebar-title-row"><h2>Explore<br /><span>the line-up</span></h2><Sparkles size={22} className="sparkle" /></div>
            <p className="sidebar-copy">Six stand-out devices. One calm place to figure out what fits your life.</p>
            <div className="category-list" role="list" aria-label="Gadget categories">
              {categories.map((category) => {
                const Icon = categoryIcons[category as keyof typeof categoryIcons];
                return <button type="button" role="listitem" key={category} className={activeCategory === category ? "category active" : "category"} onClick={() => setActiveCategory(category)}><span className="category-icon"><Icon size={16} /></span><span>{category}</span><span className="category-arrow">{activeCategory === category ? <Check size={15} /> : <ArrowUpRight size={14} />}</span></button>;
              })}
            </div>
            <div className="sidebar-tip"><div className="tip-icon"><GitCompare size={16} /></div><div><strong>Good to know</strong><p>Select up to two gadgets to compare specs side by side.</p></div></div>
          </aside>

          <section className="catalog-results" aria-labelledby="results-title">
            <div className="results-toolbar"><div><p className="section-kicker">02 / Results</p><div className="results-title-row"><h2 id="results-title">{activeCategory === "All" ? "All gadgets" : activeCategory}</h2><span className="result-count">{filteredGadgets.length.toString().padStart(2, "0")} found</span></div></div><button type="button" className="sort-button"><SlidersHorizontal size={15} /> Sort <ChevronDown size={15} /></button></div>
            <div className="gadget-grid">
              {filteredGadgets.map((gadget, index) => <GadgetCard key={gadget.id} gadget={gadget} index={index} selected={selectedId === gadget.id} isCompared={compareIds.includes(gadget.id)} onSelect={() => setSelectedId(gadget.id)} onCompare={() => toggleCompare(gadget.id)} formatPrice={formatPrice} />)}
            </div>
            {filteredGadgets.length === 0 && <div className="empty-state"><div className="empty-icon"><Search size={22} /></div><h3>No signal found</h3><p>Try a broader search or browse another category.</p><button type="button" onClick={() => { setQuery(""); setActiveCategory("All"); }}>Reset filters</button></div>}
            <div className="results-footnote"><span className="live-dot" /> Updated for the 2024 / 2025 release cycle <span>·</span> Prices shown in USD</div>
          </section>
        </section>

        <section className="detail-section container" id="detail-panel" aria-labelledby="detail-title">
          <div className="detail-heading"><div><p className="section-kicker">03 / Deep dive</p><h2 id="detail-title">Get to know<br /><span>the details.</span></h2></div><div className="detail-heading-note">No tabs. No rabbit holes.<br /><strong>Just the useful stuff.</strong></div></div>
          <div className={`detail-card accent-${selectedGadget.accent}`}>
            <div className="detail-image-wrap"><img src={selectedGadget.image} alt={`${selectedGadget.name} product detail`} /><div className="image-overlay" /><span className="detail-badge">{selectedGadget.category} · {selectedGadget.year}</span><span className="image-index">{String(gadgets.findIndex((gadget) => gadget.id === selectedGadget.id) + 1).padStart(2, "0")} / 06</span></div>
            <div className="detail-content"><div className="detail-topline"><span className="mini-label">FEATURED DEVICE</span><div className="rating"><Star size={14} fill="currentColor" /> {selectedGadget.rating} <span>({selectedGadget.reviews})</span></div></div><h3>{selectedGadget.name}</h3><p className="detail-tagline">{selectedGadget.tagline}</p><p className="detail-description">{selectedGadget.description}</p><div className="spec-grid">{selectedGadget.specs.map((spec) => <div className="spec-item" key={spec.label}><span>{spec.label}</span><strong>{spec.value}</strong></div>)}</div><div className="detail-actions"><div className="price-block"><span>Starting at · {currencyCode}</span><strong>{formatPrice(selectedGadget.price)}</strong></div><button type="button" className={favorites.includes(selectedGadget.id) ? "primary-button saved" : "primary-button"} onClick={() => toggleFavorite(selectedGadget.id)}><Bookmark size={17} fill={favorites.includes(selectedGadget.id) ? "currentColor" : "none"} /> {favorites.includes(selectedGadget.id) ? "Saved" : "Bookmark"}</button><button type="button" className="secondary-button" onClick={printSpecs}><Printer size={16} /> Print specs</button></div></div>
          </div>
        </section>

        <section className="favorites-section container" id="favorites" aria-labelledby="favorites-title">
          <div className="section-row"><div><p className="section-kicker">04 / Your shortlist</p><h2 id="favorites-title">My favorites <span className="heart-title"><Heart size={20} fill="currentColor" /></span></h2></div><span className="saved-note">Saved in this browser · {favoriteGadgets.length} {favoriteGadgets.length === 1 ? "item" : "items"}</span></div>
          {favoriteGadgets.length > 0 ? <div className="favorites-grid">{favoriteGadgets.map((gadget) => <button type="button" className="favorite-card" key={gadget.id} onClick={() => { setSelectedId(gadget.id); document.getElementById("detail-panel")?.scrollIntoView({ behavior: "smooth" }); }}><img src={gadget.image} alt="" /><span><strong>{gadget.name}</strong><small>{gadget.category} · {formatPrice(gadget.price)}</small></span><ArrowUpRight size={16} /></button>)}</div> : <div className="favorites-empty"><Heart size={20} /><p>Nothing saved yet. Tap <strong>Bookmark</strong> on a gadget you want to remember.</p></div>}
        </section>

        <section className="how-section container" id="how-it-works"><div className="how-intro"><p className="section-kicker">05 / How it works</p><h2>Less scrolling.<br /><em>More certainty.</em></h2><p>We keep the discovery playful and the decision-making practical. Search, peek at the details, then compare the finalists.</p></div><div className="how-steps"><div className="how-step"><span>01</span><Search size={20} /><h3>Search</h3><p>Start with a product type, a mood or a specific name.</p></div><div className="how-step"><span>02</span><GitCompare size={20} /><h3>Compare</h3><p>Choose two finalists and see the meaningful differences.</p></div><div className="how-step"><span>03</span><Bookmark size={20} /><h3>Save</h3><p>Bookmark the ones that feel like a good fit for later.</p></div></div></section>

        {comparedGadgets.length > 0 && <div className="compare-tray"><div className="compare-tray-copy"><span className="tray-icon"><GitCompare size={17} /></span><div><strong>Comparison tray</strong><span>{comparedGadgets.length} of 2 selected</span></div></div><div className="tray-items">{comparedGadgets.map((gadget) => <button type="button" key={gadget.id} className="tray-item" onClick={() => toggleCompare(gadget.id)}><img src={gadget.image} alt="" /><span>{gadget.name}</span><X size={14} /></button>)}{comparedGadgets.length < 2 && <span className="tray-placeholder">Select one more gadget</span>}</div>{comparedGadgets.length === 2 && <button type="button" className="compare-button" onClick={() => setIsCompareOpen(true)}>Compare now <ArrowUpRight size={16} /></button>}</div>}
      </main>

      <footer className="footer container"><a className="brand" href="#top"><span className="brand-mark"><Zap size={15} fill="currentColor" /></span><span>gadget<span className="brand-dot">.</span>catalog</span></a><p>Made for curious humans · WPR 261 project studio</p><div className="footer-links"><a href="#catalog">Browse</a><a href="#favorites">Favorites</a><a href="#how-it-works">About</a></div></footer>

      {notice && <div className="toast" role="status"><Check size={16} /> {notice}</div>}
      {isCompareOpen && <div className="modal-backdrop" role="presentation" onClick={() => setIsCompareOpen(false)}><div className="compare-modal" role="dialog" aria-modal="true" aria-labelledby="compare-title" onClick={(event) => event.stopPropagation()}><div className="modal-header"><div><p className="section-kicker">Side by side</p><h2 id="compare-title">Compare your picks</h2></div><button type="button" className="icon-button" onClick={() => setIsCompareOpen(false)} aria-label="Close comparison"><X size={20} /></button></div><div className="comparison-table"><div className="comparison-labels"><span>At a glance</span>{comparedGadgets[0].specs.map((spec) => <span key={spec.label}>{spec.label}</span>)}</div>{comparedGadgets.map((gadget) => <div className="comparison-column" key={gadget.id}><img src={gadget.image} alt="" /><h3>{gadget.name}</h3><strong className="comparison-price">{formatPrice(gadget.price)}</strong>{gadget.specs.map((spec) => <span key={spec.label}>{spec.value}</span>)}</div>)}</div><div className="modal-footer"><span><Sparkles size={15} /> Tip: the right choice is the one that fits your actual week.</span><button type="button" className="primary-button" onClick={() => setIsCompareOpen(false)}>Done</button></div></div></div>}
    </div>
  );
}

function GadgetCard({ gadget, index, selected, isCompared, onSelect, onCompare, formatPrice }: { gadget: Gadget; index: number; selected: boolean; isCompared: boolean; onSelect: () => void; onCompare: () => void; formatPrice: (usdPrice: number) => string }) {
  return <article className={`gadget-card ${selected ? "selected" : ""} accent-${gadget.accent}`} style={{ "--delay": `${index * 55}ms` } as React.CSSProperties}>
    <button type="button" className="card-image-button" onClick={onSelect} aria-label={`View details for ${gadget.name}`}><img src={gadget.image} alt="" /><span className="card-image-shade" />{gadget.badge && <span className="card-badge">{gadget.badge}</span>}<span className="card-number">0{index + 1}</span><span className="view-label">View details <ArrowUpRight size={15} /></span></button>
    <div className="card-body"><div className="card-meta"><span>{gadget.category}</span><span className="card-rating"><Star size={12} fill="currentColor" /> {gadget.rating}</span></div><button type="button" className="gadget-title" onClick={onSelect}>{gadget.name}</button><p>{gadget.tagline}</p><div className="card-footer"><strong>{formatPrice(gadget.price)}</strong><button type="button" className={isCompared ? "compare-toggle active" : "compare-toggle"} onClick={onCompare} aria-pressed={isCompared}><GitCompare size={14} /> {isCompared ? "In compare" : "Compare"}</button></div></div>
  </article>;
}

export { gadgets };
