# Gadget Catalog Studio

A polished WPR 261 gadget catalog built with React, TypeScript, CSS, and Vite. The project includes interactive search, category filtering, gadget detail views, favorites saved in the browser, a two-gadget comparison modal, print-ready specifications, responsive layouts, and a custom hero visual.

## Open in VS Code

1. Extract the ZIP file.
2. Open the extracted `gadget-catalog-studio` folder in VS Code.
3. Open the integrated terminal and run `pnpm install`.
4. Run `pnpm dev`.
5. Open the local Vite URL shown in the terminal.

## Currency support

Use the **Currency** selector in the top navigation to switch between:

- **USD** — US dollars
- **ZAR** — South African rand
- **GBP** — British pounds

The catalog stores product prices as USD base values and converts them in the browser using the demo rates in `client/src/pages/Home.tsx`:

| Currency | Demo rate |
|---|---:|
| USD | 1.00 |
| ZAR | 18.20 |
| GBP | 0.79 |

These are fixed educational/demo rates rather than a live exchange-rate feed. To update them, edit `currencyRates` in `client/src/pages/Home.tsx`.

## Useful commands

```bash
pnpm dev       # start the development server
pnpm check     # run TypeScript checks
pnpm build     # create a production build
```

## Main files

- `client/src/pages/Home.tsx` — catalog data and interactions
- `client/src/index.css` — visual design system and responsive styles
- `client/index.html` — page metadata
- `client/public/` — small public configuration assets
