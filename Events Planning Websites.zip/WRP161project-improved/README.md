# Community Afterglow — Event Website

This is an improved version of the original WRP161 event website. It keeps the project beginner-friendly and uses **HTML and CSS only**. There is no Bootstrap dependency and no JavaScript file is required for the core experience.

## Open it in VS Code

Extract the ZIP file, open the `WRP161project-improved` folder in VS Code, then open the `Html and Css/index.html` file with Live Server or in a browser. The navigation links connect the home page, event details, organisers, and contact/registration pages.

## What was improved

The redesign introduces a clear visual identity for Community Afterglow, responsive layouts for mobile and desktop, accessible navigation labels, semantic sections, stronger event hierarchy, image-led artist cards, an event schedule, venue information, organiser cards, a registration form, social links, hover states, focus states, and reduced-motion support.

The original event photography was preserved and reused. The main stylesheet is `Html and Css/event.css`, while the primary pages are `index.html`, `Eventdetails.html`, `page.html`, and `Contact.html`. `Project.html` is also included as a matching home-page entry point for compatibility with the previous project.

## Design direction

The visual system uses a midnight festival base, warm sand content sections, coral energy accents, lime highlights, editorial typography, and generous spacing. The idea is to make the project feel personal and student-built while still presenting the event as a believable community brand.

## Suggested student customisations

You can change the event date, artist names, venue details, and contact information directly in the HTML. You can adjust the colours at the top of `event.css` using the CSS variables such as `--coral`, `--lime`, and `--night`. You can also replace the image files with your own event photography as long as the filenames stay the same or the `src` paths are updated.
