# QA notes

The redesigned home page was previewed through the local static server and rendered with the new hero, lineup cards, announcement strip, experience section, venue block, and footer. The event details page rendered its facts, schedule, venue map, and registration call to action. The contact page rendered social links, a registration form, and responsive form fields.

The project uses plain HTML and CSS for the main experience. Navigation links were checked across `index.html`, `Project.html`, `Eventdetails.html`, `page.html`, and `Contact.html`. Local image paths for the hero, artists, organisers, venue, support team, and marketing team were checked successfully. No Bootstrap or JavaScript dependency is required by the redesigned pages.
